<?php

return [
    'description' => 'Customer can buy products using PayU.',
    'merchant_key' => 'Merchant Key',
    'salt_key' => 'Salt Key',
    'environment' => 'Environment',
    'production' => 'Production',
    'test' => 'Test',
];
