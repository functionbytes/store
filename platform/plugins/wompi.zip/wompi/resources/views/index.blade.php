{{-- resources/views/plugins/wompi/index.blade.php --}}
@include('plugins/wompi::settings')
