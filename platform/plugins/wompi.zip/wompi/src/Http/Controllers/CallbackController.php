<?php

namespace Functionbytes\Wompi\Http\Controllers;

use Botble\Ecommerce\Models\Order;
use Illuminate\Http\Request;
use Botble\Base\Http\Controllers\BaseController;

class CallbackController extends BaseController
{
    public function callback(Request $request)
    {
        try {
            $reference = $request->get('id'); // Wompi devuelve el reference como 'id'

            if (empty($reference)) {
                \Log::error('Wompi Callback: No reference received', [
                    'request_data' => $request->all()
                ]);
                return redirect()->route('public.checkout.success')->with('error_msg', 'Error en el pago: referencia no encontrada');
            }

            // Buscar la orden por token
            $order = Order::findByToken($reference);

            if (!$order) {
                \Log::error('Wompi Callback: Order not found', [
                    'reference' => $reference,
                    'request_data' => $request->all()
                ]);
                return redirect()->route('public.checkout.success')->with('error_msg', 'Orden no encontrada');
            }

            \Log::info('Wompi Callback: Order found', [
                'order_id' => $order->id,
                'order_code' => $order->code,
                'order_token' => $order->token,
                'reference' => $reference,
                'payment_status' => $request->get('status')
            ]);

            // Continuar con el procesamiento del callback...

        } catch (\Exception $e) {
            \Log::error('Wompi Callback Error', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }
    }
}
