<?php

namespace Functionbytes\Wompi\Services;

use Botble\Payment\Services\Abstracts\PaymentAbstract;
use Functionbytes\Wompi\Providers\WompiServiceProvider;
use Illuminate\Http\Request;
use Throwable;

class WompiPaymentService extends PaymentAbstract
{
    public function makePayment(Request $request): string
    {


        $paymentData = $this->preparePaymentData($request);

        try {
            $wompiService = new WompiService();
            $orderToken = $this->getOrderToken($paymentData);

            dump($orderToken);

            \Log::info('Wompi Payment: Order token details', [
                'order_token' => $orderToken,
                'payment_data_token' => $paymentData['token'] ?? 'not_set',
                'order_id' => $paymentData['order_id'] ?? 'not_set',
                'amount' => $paymentData['amount'],
                'currency' => $paymentData['currency'] ?? 'COP',
                'customer_email' => $paymentData['address']['email'] ?? 'N/A'
            ]);

// Preparar datos para Wompi Web Checkout
            $wompiService->withData([
                'reference' => $orderToken, // Usar el token único de la orden
                'amount'           => $paymentData['amount'],
                'currency'         => $paymentData['currency'] ?? 'COP',
                'customer_email'   => $paymentData['address']['email'],
                'customer_name'    => trim(($paymentData['address']['first_name'] ?? '') . ' ' . ($paymentData['address']['last_name'] ?? '')),
                'customer_phone'   => $paymentData['address']['phone'] ?? '',
                'redirect_url'     => route('payment.wompi.callback'), // URL de retorno
                'tax'              => $this->calculateTax($paymentData['amount']),
                // Datos completos de dirección de envío
                'shipping_address' => $paymentData['address']['address'] ?? '',
                'shipping_city'    => $paymentData['address']['city'] ?? '',
                'shipping_region'  => $paymentData['address']['state'] ?? $paymentData['address']['region'] ?? '',
                'shipping_phone'   => $paymentData['address']['phone'] ?? '',
                'shipping_country' => $paymentData['address']['country'] ?? 'CO', // Colombia por defecto
            ]);

            // Redirigir al Web Checkout de Wompi
            $wompiService->redirectToCheckoutPage();

            // Este return nunca se ejecutará porque redirectToCheckoutPage() hace exit()
            return '';

        } catch (Throwable $exception) {
            $this->setErrorMessageAndLogging($exception);
            return '';
        }
    }

    private function getOrderToken(array $paymentData): string
    {
        // 1. Intentar obtener del token directo en paymentData
        if (!empty($paymentData['token'])) {
            \Log::info('Wompi: Using token from paymentData', ['token' => $paymentData['token']]);
            return $paymentData['token'];
        }

        // 2. Intentar obtener usando order_id
        if (!empty($paymentData['order_id'])) {
            $order = Order::find($paymentData['order_id']);
            if ($order && !empty($order->token)) {
                \Log::info('Wompi: Using token from Order model', [
                    'order_id' => $paymentData['order_id'],
                    'token' => $order->token
                ]);
                return $order->token;
            }
        }

        // 3. Buscar por código de orden si existe
        if (!empty($paymentData['order_code'])) {
            $order = Order::where('code', $paymentData['order_code'])->first();
            if ($order && !empty($order->token)) {
                \Log::info('Wompi: Using token from Order by code', [
                    'order_code' => $paymentData['order_code'],
                    'token' => $order->token
                ]);
                return $order->token;
            }
        }

        // 4. Como último recurso, generar un token temporal
        $fallbackToken = 'TEMP_ORDER_' . time() . '_' . str_random(8);

        \Log::warning('Wompi: No order token found, using fallback', [
            'fallback_token' => $fallbackToken,
            'payment_data_keys' => array_keys($paymentData),
            'order_id' => $paymentData['order_id'] ?? 'not_set',
            'order_code' => $paymentData['order_code'] ?? 'not_set'
        ]);

        return $fallbackToken;
    }


    public function afterMakePayment(Request $request)
    {
        // No se necesita implementación ya que la redirección se maneja en makePayment
        // y el procesamiento del pago se hace vía webhook
    }

    public function getServiceProvider(): string
    {
        return WompiServiceProvider::MODULE_NAME;
    }

    public function isSupportRefundOnline(): bool
    {
        return false; // Wompi soporta reembolsos pero requiere implementación adicional
    }

    public function refund(string $chargeId, float $amount, array $options = []): array
    {
        // TODO: Implementar reembolsos usando la API de Wompi
        // Por ahora retornamos error
        return [
            'error' => true,
            'message' => 'Refunds are not implemented yet for Wompi.',
        ];
    }

    /**
     * Calculate tax based on Colombian tax rules
     * This is a simple example - adjust according to your business needs
     */
    private function calculateTax(float $amount): float
    {
        // Colombian IVA is typically 19%
        // Adjust this calculation based on your tax requirements
        return $amount * 0.19;
    }
}
