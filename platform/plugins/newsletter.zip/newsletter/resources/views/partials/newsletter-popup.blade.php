<div
    class="modal fade newsletter-popup"
    id="newsletter-popup"
    tabindex="-1"
    aria-hidden="true"
    data-delay="{{ theme_option('newsletter_popup_delay', 5) }}"
    title="{{ theme_option('newsletter_popup_title') }}"
    data-url="{{ route('public.ajax.newsletter-popup') }}"
>



</div>

