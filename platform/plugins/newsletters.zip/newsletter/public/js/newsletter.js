class NewsletterManager {
    constructor() {
        this.modal = null;
        this.form = null;
        this.popup = null;
        this.isModalEnabled = false;
        this.isPopupEnabled = false;
        this.collectName = false;
        this.init();
    }

    init() {
        // Detectar qué tipo de newsletter está habilitado
        this.modal = document.getElementById('newsletterModal');
        this.popup = document.getElementById('newsletter-popup');

        this.isModalEnabled = this.modal !== null;
        this.isPopupEnabled = this.popup !== null;
        this.collectName = document.querySelector('input[name="name"]') !== null;

        if (this.isModalEnabled) {
            this.initModal();
        } else if (this.isPopupEnabled) {
            this.initPopup();
        }
    }

    // ========================================
    // NUEVA FUNCIONALIDAD: MODAL
    // ========================================
    initModal() {
        this.modal = new bootstrap.Modal(document.getElementById('newsletterModal'));
        this.form = document.getElementById('newsletter-modal-form');

        const delay = parseInt(document.getElementById('newsletterModal').dataset.delay) || 5;

        // Mostrar modal después del delay si no se ha suscrito
        if (!this.hasUserSubscribed()) {
            setTimeout(() => {
                this.modal.show();
            }, delay * 1000);
        }

        // Manejar envío del formulario
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleModalSubmit();
        });

        // Limpiar errores al escribir
        this.form.addEventListener('input', (e) => {
            this.clearFieldError(e.target);
        });

        // Marcar como cerrado cuando se cierra el modal
        document.getElementById('newsletterModal').addEventListener('hidden.bs.modal', () => {
            this.setCookie('newsletter_modal_closed', '1', 1); // 1 día
        });
    }

    async handleModalSubmit() {
        const submitBtn = this.form.querySelector('.newsletter-submit-btn');
        const submitText = submitBtn.querySelector('.newsletter-submit-text');
        const loadingText = submitBtn.querySelector('.newsletter-loading');

        // Limpiar errores previos
        this.clearAllErrors();

        // Obtener datos del formulario
        const formData = new FormData(this.form);
        const data = {
            email: formData.get('email'),
            _token: formData.get('_token')
        };

        if (this.collectName) {
            data.name = formData.get('name');
        }

        // Validación básica del lado del cliente
        if (!this.validateForm(data)) {
            return;
        }

        // Mostrar loading
        submitBtn.disabled = true;
        submitText.classList.add('d-none');
        loadingText.classList.remove('d-none');

        try {
            const response = await fetch('/newsletter/subscribe', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': data._token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (response.ok && result.error === false) {
                this.showMessage(result.message || '¡Gracias por suscribirte!', 'success');
                this.markUserAsSubscribed();

                // Limpiar formulario
                this.form.reset();

                // Disparar evento personalizado
                document.dispatchEvent(new CustomEvent("newsletter.subscribed"));

                // Cerrar modal después de 2 segundos
                setTimeout(() => {
                    if (this.modal) {
                        this.modal.hide();
                    }
                }, 2000);

            } else {
                // Manejar errores de validación del servidor
                if (result.errors) {
                    this.displayValidationErrors(result.errors);
                } else {
                    this.showMessage(result.message || 'Ha ocurrido un error. Inténtalo de nuevo.', 'error');
                }
            }

        } catch (error) {
            console.error('Newsletter subscription error:', error);
            this.showMessage('Error de conexión. Inténtalo de nuevo.', 'error');
        } finally {
            // Ocultar loading
            submitBtn.disabled = false;
            submitText.classList.remove('d-none');
            loadingText.classList.add('d-none');
        }
    }

    // ========================================
    // FUNCIONALIDAD ORIGINAL: POPUP
    // ========================================
    initPopup() {
        const popup = $(this.popup);
        const delay = 1000 * popup.data("delay") || 5000;

        const setCookie = (days) => {
            const date = new Date();
            date.setTime(date.getTime() + days);
            document.cookie = `newsletter_popup=1; expires=${date.toUTCString()}; path=/`;
        };

        if (popup.length > 0) {
            // Solo mostrar si no hay cookie
            if (document.cookie.indexOf("newsletter_popup=1") === -1) {
                fetch(popup.data("url"), {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Accept: "application/json"
                    }
                }).then(response => {
                    if (!response.ok) throw new Error("Network response was not ok");
                    return response.json();
                }).then(result => {
                    const data = result.data;
                    popup.html(data.html);

                    // Actualizar lazy loading si existe
                    if (typeof Theme !== "undefined" && Theme.lazyLoadInstance !== undefined) {
                        Theme.lazyLoadInstance.update();
                    }

                    setTimeout(() => {
                        if (popup.find(".newsletter-popup-content").length) {
                            popup.modal("show");
                        }
                    }, delay);
                }).catch(error => {
                    console.error("Fetch error:", error);
                });
            }

            // Manejar eventos del modal
            popup.on("show.bs.modal", () => {
                const dialog = popup.find(".modal-dialog");
                dialog.css("margin-top", Math.max(0, ($(window).height() - dialog.height()) / 2) / 2);
            }).on("hide.bs.modal", () => {
                const dontShowAgain = popup.find("form").find('input[name="dont_show_again"]').is(":checked");
                setCookie(dontShowAgain ? 2592000000 : 3600000); // 30 días o 1 hora
            });

            // Event listener para suscripción exitosa
            document.addEventListener("newsletter.subscribed", () => setCookie(365 * 24 * 60 * 60 * 1000)); // 1 año
        }

        // Manejar envío de formularios del popup
        this.initPopupFormHandlers();
    }

    initPopupFormHandlers() {
        const showError = (message) => {
            $(".newsletter-error-message").html(message).show();
        };

        const showErrors = (errors) => {
            let message = "";
            $.each(errors, (key, value) => {
                if (message !== "") message += "<br />";
                message += value;
            });
            showError(message);
        };

        const showSuccess = (message) => {
            $(".newsletter-success-message").html(message).show();
        };

        $(document).on("submit", "form.bb-newsletter-popup-form", (event) => {
            event.preventDefault();

            const form = $(event.currentTarget);
            const submitBtn = form.find("button[type=submit]");

            $(".newsletter-success-message").html("").hide();
            $(".newsletter-error-message").html("").hide();

            $.ajax({
                type: "POST",
                cache: false,
                url: form.prop("action"),
                data: new FormData(form[0]),
                contentType: false,
                processData: false,
                beforeSend: () => {
                    submitBtn.prop("disabled", true).addClass("btn-loading");
                },
                success: (response) => {
                    const { error, message } = response;

                    if (error) {
                        showError(message);
                    } else {
                        form.find('input[name="email"]').val("");
                        showSuccess(message);
                        document.dispatchEvent(new CustomEvent("newsletter.subscribed"));

                        setTimeout(() => {
                            this.popup && $(this.popup).modal("hide");
                        }, 5000);
                    }
                },
                error: (xhr) => {
                    if (xhr.errors && xhr.errors.length) {
                        showErrors(xhr.errors);
                    } else if (xhr.responseJSON) {
                        if (xhr.responseJSON.errors) {
                            if (xhr.status === 422) {
                                showErrors(xhr.responseJSON.errors);
                            }
                        } else if (xhr.responseJSON.message) {
                            showError(xhr.responseJSON.message);
                        } else {
                            $.each(xhr.responseJSON, (key, value) => {
                                $.each(value, (k, v) => {
                                    showError(v);
                                });
                            });
                        }
                    } else {
                        showError(xhr.statusText);
                    }
                },
                complete: () => {
                    if (typeof refreshRecaptcha !== "undefined") {
                        refreshRecaptcha();
                    }
                    submitBtn.prop("disabled", false).removeClass("btn-loading");
                }
            });
        });
    }

    // ========================================
    // MÉTODOS COMPARTIDOS
    // ========================================
    validateForm(data) {
        let isValid = true;

        // Validar email
        if (!data.email || !this.isValidEmail(data.email)) {
            this.setFieldError('newsletter-email', 'Por favor, ingresa un email válido.');
            isValid = false;
        }

        // Validar nombre si es requerido
        if (this.collectName && (!data.name || data.name.trim().length < 2)) {
            this.setFieldError('newsletter-name', 'Por favor, ingresa tu nombre (mínimo 2 caracteres).');
            isValid = false;
        }

        // Validar formato del nombre
        if (this.collectName && data.name && !/^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s]+$/.test(data.name)) {
            this.setFieldError('newsletter-name', 'El nombre solo puede contener letras y espacios.');
            isValid = false;
        }

        return isValid;
    }

    displayValidationErrors(errors) {
        Object.keys(errors).forEach(field => {
            const inputId = field === 'email' ? 'newsletter-email' : 'newsletter-name';
            const message = Array.isArray(errors[field]) ? errors[field][0] : errors[field];
            this.setFieldError(inputId, message);
        });
    }

    setFieldError(inputId, message) {
        const input = document.getElementById(inputId);
        if (input) {
            input.classList.add('is-invalid');

            // Buscar o crear mensaje de error
            let errorDiv = input.parentNode.querySelector('.invalid-feedback');
            if (!errorDiv) {
                errorDiv = document.createElement('div');
                errorDiv.className = 'invalid-feedback';
                input.parentNode.appendChild(errorDiv);
            }
            errorDiv.textContent = message;
        }
    }

    clearFieldError(input) {
        input.classList.remove('is-invalid');
        const errorDiv = input.parentNode.querySelector('.invalid-feedback');
        if (errorDiv) {
            errorDiv.remove();
        }
    }

    clearAllErrors() {
        const inputs = this.form.querySelectorAll('.newsletter-input');
        inputs.forEach(input => {
            this.clearFieldError(input);
        });

        const messageDiv = this.form.querySelector('.newsletter-message');
        if (messageDiv) {
            messageDiv.textContent = '';
            messageDiv.className = 'newsletter-message';
        }
    }

    showMessage(message, type) {
        const messageDiv = this.form.querySelector('.newsletter-message');
        if (messageDiv) {
            messageDiv.textContent = message;
            messageDiv.className = `newsletter-message ${type}`;

            // Limpiar mensaje después de 5 segundos
            setTimeout(() => {
                messageDiv.textContent = '';
                messageDiv.className = 'newsletter-message';
            }, 5000);
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    hasUserSubscribed() {
        return this.getCookie('newsletter_subscribed') === '1' ||
            this.getCookie('newsletter_modal_closed') === '1' ||
            this.getCookie('newsletter_popup') === '1';
    }

    markUserAsSubscribed() {
        this.setCookie('newsletter_subscribed', '1', 365); // 1 año
    }

    setCookie(name, value, days) {
        const expires = new Date();
        expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000));
        document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/;SameSite=Lax`;
    }

    getCookie(name) {
        const nameEQ = name + "=";
        const ca = document.cookie.split(';');
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    new NewsletterManager();
});

// ========================================
// CÓDIGO LEGACY PARA COMPATIBILIDAD
// ========================================
// Mantener el código jQuery original para compatibilidad con temas existentes
$(() => {
    // Este código se ejecutará solo si no se ha inicializado la clase NewsletterManager
    // o si hay elementos específicos que requieren el comportamiento original

    // Solo ejecutar si no hay modal nuevo
    if (!document.getElementById('newsletterModal')) {
        console.log('Loading legacy newsletter popup functionality');
        // El código legacy se maneja ahora dentro de la clase NewsletterManager
    }
});
