<?php

if (! defined('NEWSLETTER_MODULE_SCREEN_NAME')) {
    define('NEWSLETTER_MODULE_SCREEN_NAME', 'newsletter');
}
