<?php

namespace Botble\Newsletter\Repositories\Caches;

use Botble\Newsletter\Repositories\Eloquent\NewsletterRepository;

/**
 * @deprecated
 */
class NewsletterCacheDecorator extends NewsletterRepository
{
}
