<?php

namespace Botble\Newsletter\Repositories\Eloquent;

use Botble\Newsletter\Repositories\Interfaces\NewsletterInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class NewsletterRepository extends RepositoriesAbstract implements NewsletterInterface
{
}
