<?php

namespace Botble\Newsletter\Http\Controllers;

use Botble\Base\Http\Actions\DeleteResourceAction;
use Botble\Base\Http\Controllers\BaseController;
use Botble\Newsletter\Http\Requests\NewsletterRequest;
use Botble\Newsletter\Models\Newsletter;
use Botble\Newsletter\Tables\NewsletterTable;
use Illuminate\Http\JsonResponse;

class NewsletterController extends BaseController
{

    public function __construct(protected NewsletterInterface $newsletterRepository)
    {
    }


    public function index(NewsletterTable $dataTable)
    {
        $this->pageTitle(trans('plugins/newsletter::newsletter.name'));

        return $dataTable->renderTable();
    }

    public function destroy(Newsletter $newsletter)
    {
        return DeleteResourceAction::make($newsletter);
    }

    public function postSubscribe(NewsletterRequest $request): JsonResponse
    {
        $email = $request->input('email');
        $name = $request->input('name', ''); // Obtener nombre si está presente

        $newsletter = $this->newsletterRepository->getFirstBy(['email' => $email]);

        if ($newsletter) {
            return response()->json([
                'error' => false,
                'message' => __('You have subscribed to our newsletter successfully!'),
            ]);
        }

        $data = [
            'email' => $email,
            'status' => 'subscribed',
        ];

        // Agregar nombre si está disponible
        if (!empty($name)) {
            $data['name'] = $name;
        }

        $this->newsletterRepository->createOrUpdate($data);

        // Enviar a servicio de email marketing si está configurado
        if (setting('newsletter_mailjet_api_key') || setting('newsletter_sendgrid_api_key')) {
            try {
                $newsletterService = app('newsletter');

                $subscriberData = ['email' => $email];
                if (!empty($name)) {
                    $subscriberData['name'] = $name;
                }

                $newsletterService->subscribe($subscriberData);
            } catch (\Exception $e) {
                \Log::error('Newsletter service error: ' . $e->getMessage());
            }
        }

        return response()->json([
            'error' => false,
            'message' => __('You have subscribed to our newsletter successfully!'),
        ]);
    }


}
