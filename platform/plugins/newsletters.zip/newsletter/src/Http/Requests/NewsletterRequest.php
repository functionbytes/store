<?php

namespace Botble\Newsletter\Http\Requests;

use Botble\Newsletter\Enums\NewsletterStatusEnum;
use Botble\Newsletter\Models\Newsletter;
use Botble\Support\Http\Requests\Request;
use Illuminate\Database\Query\Builder;
use Illuminate\Validation\Rule;

class NewsletterRequest extends Request
{
    protected $errorBag = 'newsletter';

    public function rules(): array
    {
        return [
            'email' => [
                'required',
                'email',
                Rule::unique((new Newsletter())->getTable())->where(function (Builder $query): void {
                    $query->where('status', NewsletterStatusEnum::SUBSCRIBED);
                }),
            ],
            'name' => [
                'nullable',
                'string',
                'max:255',
                'min:2',
                'regex:/^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s]+$/', // Solo letras, espacios y caracteres latinos
            ],
            'status' => Rule::in(NewsletterStatusEnum::values()),
        ];
    }

    public function messages(): array
    {
        return [
            'email.required' => __('El campo email es obligatorio.'),
            'email.email' => __('Por favor, ingresa un email válido.'),
            'email.unique' => __('Este email ya está suscrito a nuestro newsletter.'),
            'name.string' => __('El nombre debe ser texto válido.'),
            'name.max' => __('El nombre no puede tener más de 255 caracteres.'),
            'name.min' => __('El nombre debe tener al menos 2 caracteres.'),
            'name.regex' => __('El nombre solo puede contener letras y espacios.'),
        ];
    }

    public function attributes(): array
    {
        return [
            'email' => __('Email'),
            'name' => __('Nombre'),
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        // Limpiar y formatear el nombre si está presente
        if ($this->has('name') && !empty($this->input('name'))) {
            $this->merge([
                'name' => trim($this->input('name')),
            ]);
        }
    }

    /**
     * Handle a passed validation attempt.
     */
    protected function passedValidation(): void
    {
        // Capitalizar el nombre después de la validación
        if ($this->has('name') && !empty($this->validated()['name'])) {
            $this->merge([
                'name' => ucwords(strtolower($this->validated()['name'])),
            ]);
        }
    }
}
