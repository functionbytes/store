

    <!-- Newsletter Modal -->
    <div class="modal fade" id="newsletterModal" tabindex="-1" aria-labelledby="newsletterModalLabel" aria-hidden="true" data-delay="{{ theme_option('newsletter_popup_delay', 5) }}">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content newsletter-modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center p-4">
                    @if ($image = theme_option('newsletter_popup_image'))
                        <div class="newsletter-modal-image mb-3">
                            <img src="{{ RvMedia::getImageUrl($image) }}" alt="{{ theme_option('newsletter_popup_title') }}" class="img-fluid rounded">
                        </div>
                    @endif

                    @if ($title = theme_option('newsletter_popup_title'))
                        <h4 class="newsletter-modal-title mb-3">{{ $title }}</h4>
                    @endif

                    @if ($subtitle = theme_option('newsletter_popup_subtitle'))
                        <h6 class="newsletter-modal-subtitle mb-3 text-muted">{{ $subtitle }}</h6>
                    @endif

                    @if ($description = theme_option('newsletter_popup_description'))
                        <p class="newsletter-modal-description mb-4">{{ $description }}</p>
                    @endif

                    <form class="newsletter-form" id="newsletter-modal-form">
                        @csrf
                        <div class="newsletter-form-group">
                            @if (theme_option('newsletter_collect_name', false))
                                <div class="mb-3">
                                    <input
                                        type="text"
                                        name="name"
                                        id="newsletter-name"
                                        class="form-control newsletter-input"
                                        placeholder="{{ theme_option('newsletter_name_placeholder', __('Enter your name')) }}"
                                        required
                                    >
                                </div>
                            @endif

                            <div class="mb-3">
                                <input
                                    type="email"
                                    name="email"
                                    id="newsletter-email"
                                    class="form-control newsletter-input"
                                    placeholder="{{ theme_option('newsletter_email_placeholder', __('Enter your email')) }}"
                                    required
                                >
                            </div>

                            <button type="submit" class="btn btn-primary newsletter-submit-btn w-100">
                                <span class="newsletter-submit-text">{{ theme_option('newsletter_submit_text', __('Subscribe')) }}</span>
                                <span class="newsletter-loading d-none">
                                    <i class="fas fa-spinner fa-spin"></i> {{ __('Subscribing...') }}
                                </span>
                            </button>
                        </div>

                        <div class="newsletter-message mt-3"></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
